#include "device.h"

/* Write your code here */


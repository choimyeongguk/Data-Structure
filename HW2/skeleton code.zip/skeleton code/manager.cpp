#include "manager.h"

/* Write your code here */

